MALE HUNTER - 2D Pixel Art Character (8 directions)
Version 1.0

CONTENTS
  Idle/      8 directions, 1 frame each
  Walk/      8 directions, 8 frames each (64 frames)
  Interact/  8 directions, 1 frame each
  Sit/       8 directions, 1 frame each
  Sleep/     8 directions, 1 frame each
  Previews/  showcase GIFs (one per direction) + 8-direction Walk grid
  metadata.json  lists every state, direction and frame path

SPECS
  Canvas:      120x120 px per frame, transparent background
  Character:   approx. 50x60 px
  View:        low top-down (3/4)
  Directions:  south, south-east, east, north-east, north, north-west, west, south-west
  Frames:      frame_00.png, frame_01.png ... in play order
  Suggested:   Walk 10 fps
  Walk frames are body-stabilised and share the Idle ground line, so states swap without jumping.

LICENSE
  Free for personal and commercial projects.
  Do not resell or redistribute as a game asset.
  Credit is appreciated but not required.
  Modify as needed.
  No NFT use.
